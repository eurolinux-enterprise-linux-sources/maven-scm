how to build mercurial (hg) scm provider?

you must have mercurial (hg) installed on your machine. mercurial is available at http://selenic.com/mercurial. 

the mercurial provider is basically a copy of the bzr provider written by mailto:torbjorn@smorgrav.org">torbj�rn eikli sm�rgrav.

